#!/bin/bash
DATE=$(date +%F)
TIME=$(date +%H:%M:%S)
MIN=30
MAX=1800
FILENAME=$(echo $0 | sed -e "s/\/root.\///g" | sed -e "s/\/root\///g")
echo "[$$] ${DATE} ${TIME} Скрипт запущен" >> report_${FILENAME}.log
SLEEP_TIME_SEC=0
while [ "$SLEEP_TIME_SEC" -le $MIN ]
do
  SLEEP_TIME_SEC=$RANDOM
  let "SLEEP_TIME_SEC %= $MAX"
done
echo "Время ожидания: $SLEEP_TIME_SEC" >> report_${FILENAME}.log
sleep $SLEEP_TIME_SEC
DATE=$(date +%F)
TIME=$(date +%H:%M:%S)
let "SLEEP_TIME_SEC /= 60"
echo "[$$] ${DATE} ${TIME} Скрипт завершился, работал ${SLEEP_TIME_SEC} минут" >> report_${FILENAME}.log

