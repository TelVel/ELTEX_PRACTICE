#!/bin/bash
config="scripts.conf"
log="observer.log"
while read -r scripts; do
	if ! pgrep -f "$scripts" > /dev/null;
		then
		nohup "$scripts" &
		echo "$(date '+%F %H:%M:%S') скрипт $scripts был перезапущен" >> "$log"
	fi
done < "$config"
